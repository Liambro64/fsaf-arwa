/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lbrookes <lbrookes@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/20 13:36:59 by lbrookes          #+#    #+#             */
/*   Updated: 2023/11/21 11:01:14 by lbrookes         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	check_is_lowercase(char *c)
{
	if (c[0] >= 97 && c[0] <= 122)
		return (1);
	return (0);
}

int	ft_str_is_lowercase(char *str)
{
	while (*str)
	{
		if (check_is_lowercase(str) == 1)
			str++;
		else
			return (0);
	}
	return (1);
}
