/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lbrookes <lbrookes@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/20 13:36:59 by lbrookes          #+#    #+#             */
/*   Updated: 2023/11/21 11:01:17 by lbrookes         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	check_is_printable(char *c)
{
	if (c[0] >= 32 && c[0] <= 126)
		return (1);
	return (0);
}

int	ft_str_is_printable(char *str)
{
	while (*str)
	{
		if (check_is_printable(str) == 1)
			str++;
		else
			return (0);
	}
	return (1);
}
