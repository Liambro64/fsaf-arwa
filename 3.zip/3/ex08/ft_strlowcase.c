/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlowcase.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lbrookes <lbrookes@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/20 14:28:41 by lbrookes          #+#    #+#             */
/*   Updated: 2023/11/21 14:32:31 by lbrookes         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	check_is_uppercase(char *c)
{
	if (c[0] >= 65 && c[0] <= 90)
		return (1);
	return (0);
}

char	*ft_strlowcase(char *str)
{
	char	*placeholder;

	placeholder = str;
	while (*str)
	{
		if (check_is_uppercase(str) == 1)
			*str += 32;
		str++;
	}
	return (placeholder);
}
