/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lbrookes <lbrookes@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/20 13:36:59 by lbrookes          #+#    #+#             */
/*   Updated: 2023/11/21 11:47:06 by lbrookes         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	check_is_number(char *c)
{
	if (c[0] >= 48 && c[0] <= 57)
		return (1);
	return (0);
}

int	ft_str_is_numeric(char *str)
{
	while (*str)
	{
		if (check_is_number(str) == 1)
			str++;
		else
			return (0);
	}
	return (1);
}
