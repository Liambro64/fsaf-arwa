/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lbrookes <lbrookes@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/20 13:36:59 by lbrookes          #+#    #+#             */
/*   Updated: 2023/11/21 11:51:16 by lbrookes         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	check_is_letter(char *c)
{
	if ((c[0] >= 65 && c[0] <= 90) || (c[0] >= 97 && c[0] <= 122))
		return (1);
	return (0);
}

int	ft_str_is_alpha(char *str)
{
	while (*str != '\0')
	{
		if (check_is_letter(str) == 1)
			str++;
		else
			return (0);
	}
	return (1);
}
