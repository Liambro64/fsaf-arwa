/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lbrookes <lbrookes@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/20 13:11:27 by lbrookes          #+#    #+#             */
/*   Updated: 2023/11/21 14:31:46 by lbrookes         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcpy(char *dest, char	*src)
{
	char	*placeholder;

	placeholder = dest;
	while (*src)
	{
		*dest = *src;
		src++;
		dest++;
	}
	return (placeholder);
}
